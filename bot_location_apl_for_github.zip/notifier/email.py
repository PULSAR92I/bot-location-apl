import smtplib
from email.mime.text import MIMEText
from settings import EMAIL_ADDRESS, EMAIL_PASSWORD, EMAIL_SMTP

def send_email(subject, body):
    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = EMAIL_ADDRESS
    msg["To"] = EMAIL_ADDRESS

    with smtplib.SMTP_SSL(EMAIL_SMTP, 465) as server:
        server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        server.send_message(msg)
