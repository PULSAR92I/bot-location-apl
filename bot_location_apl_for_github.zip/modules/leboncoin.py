import requests
from bs4 import BeautifulSoup
import time

def fetch_leboncoin():
    url = "https://www.leboncoin.fr/recherche?category=10&locations=Paris_75000,Hauts-de-Seine_92"
    response = requests.get(url)
    soup = BeautifulSoup(response.text, "html.parser")

    annonces = []
    for item in soup.select('li[data-qa-id="aditem_container"]'):
        try:
            titre = item.select_one("p").text.strip()
            lien = "https://www.leboncoin.fr" + item.a["href"]
            prix_text = item.select_one("span[data-qa-id='price']").text.strip().replace("€", "").replace(" ", "")
            prix = int(prix_text)

            if prix < 600 or prix > 900:
                continue

            detail = requests.get(lien)
            time.sleep(0.5)
            detail_soup = BeautifulSoup(detail.text, "html.parser")
            description = detail_soup.get_text().lower()

            annonces.append({
                "titre": titre,
                "lien": lien,
                "prix": f"{prix} €",
                "apl": "apl" in description
            })
        except:
            continue
    return annonces
