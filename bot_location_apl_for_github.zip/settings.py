# Email settings
EMAIL_ADDRESS = "paulblainblain@gmail.com"
EMAIL_PASSWORD = "VOTRE_MOT_DE_PASSE_ICI"
EMAIL_SMTP = "smtp.gmail.com"
