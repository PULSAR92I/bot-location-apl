import time
import json
from modules import leboncoin
from notifier.email import send_email

HISTO_FILE = "data/historique.json"

def charger_historique():
    try:
        with open(HISTO_FILE, "r") as f:
            return set(json.load(f))
    except:
        return set()

def sauvegarder_historique(histo):
    with open(HISTO_FILE, "w") as f:
        json.dump(list(histo), f)

def main():
    deja_vues = charger_historique()
    while True:
        annonces = leboncoin.fetch_leboncoin()
        for annonce in annonces:
            if annonce["lien"] not in deja_vues:
                deja_vues.add(annonce["lien"])
                titre = f"📢 Nouvelle annonce : {annonce['titre']}"
                corps = f"{annonce['prix']}
{annonce['lien']}
APL : {'Oui' if annonce['apl'] else 'Non'}"
                send_email(titre, corps)
        sauvegarder_historique(deja_vues)
        time.sleep(60)

if __name__ == "__main__":
    main()
